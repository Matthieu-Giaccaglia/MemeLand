        <section>
            <br/>
            <p>
                Bienvenue à notre site qui vend des objets retouchés par vous sur le net, oui c'est ce que nous faisons. Nous vendons des mugs, T-shirts et pulls retouchés avec notre logo dessus.<br/> <b>Edition limité</b> alors dépechez vous ! 
            </p>
        </section>

        <aside>
            <p>
                C'est un <b>projet</b> Html CSS que <b>nous</b> faisons en Conception Doc mais les vetements vendus sont réels !
                C'est faux
            </p>
        </aside>
        
        <section>
            <p>
                Le <b>cycle</b> d'achat
            </p>
                <article>
                	<h2>1</h2>
                    <h3>On achète les T-shirts</h3>
                    <p>Nos T-shirts viennent du Bengladesh et ont été créés dans les standards du Développement durable</p>
                	<h3>On achète les Pulls</h3>
                	<p>Nos Pulls viennent du Bengladesh aussi et ont été créés dans les standards du Développement durable</p>
                	<h3>On achète les chaussures</h3>
                	<p>Nos Chaussures viennent d'Inde et ont été créées dans les standards du Développement durable</p>
                	<h3>On achète les pins</h3>
                	<p>Nos Pins viennent de Chine et ont été créées dans les standards de faire de l'argent</p>
                </article>
            <p>
                On a des fournisseurs venant des 4 coins du monde, qui nous fournissent de tout
            </p>
                <article>
                	<h2>2</h2>
                    <h3>Choix</h3>
                    <p>Choisit quel vetement tu veux</p>
                    <h3>Customisation</h3>
                    <p>On met notre logo dessus</p>
                </article>
            <p>
            	Représente la culture du meme
            </p>
                <article>
                	<h2>3</h2>
                    <h3>Vente</h3>
                    <p>Une fois que t'as choisi lequel tu veux, tu l'achètes pour un pris modeste</p>
                </article>   
            <p>
            	<b>20$</b> un T-shirt + taxes
            </p>    
                <article>
                	<h2>4</h2>
                    <h3>Envoi</h3>
                    <p>On te l'envoie en moins d'<b>une semaine</b> (seulement en France)</p>
                </article>   
            <p>
            	Rapide<br/>et<br/>Efficace
            </p>
                <article>
                	<h2>5</h2>
                	<h3>Va le chercher</h3>
                    <p>A la poste s'il n'est pas delivré chez toi</p>
                    <h3>Ouvre le colis</h3>
                    <p>!--sans commentaire--</p>
                    <h3>Rock it</h3>
                    <p>Il est chez toi manque plus qu'à l'utiliser et flexer sur tes amis</p>
                </article>   
            <p>
            	C'est bon ! On a l'argent, t'as le vetement
            </p>         
        </section>

        <aside>
        	<p>
        		Cela vient dans le cadre du projet de Conception Doc de l'IUT Montpellier-Sète
        	</p>
        </aside>

        <section>
        	<p>
        		Vous pouvez vous <b>inscrire</b> pour avoir des réductions réservées aux abonnés, etre prévenue de réduction 
        		si vous le souhaitez, meme proposez votre modèle !
        	</p>
        </section>