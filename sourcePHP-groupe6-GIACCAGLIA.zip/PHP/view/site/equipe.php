<main id="Equipe">
      <article class="seul">
        <h2>Directeur des Ressources Hummaines</h2>
        <p class="jtexte">
          <strong>Regam Reda </strong> 
          <img src="./public/images/reda.jpg" alt="Réda" class="perso"> 
          Né le 06 Septembre 1999 à Saint-Paul.
          Diplômé d'un : Master en management Master en ressources humaines
          Employé depuis 5 ans
          Gère la cohésion de notre équipe
          Aime les M&M's et South Park.
        </p>
      </article>

      <article class="seul">
        <h2>Directeur artistique</h2>
        <p class="jtexte"> 
          <strong>Walter deneuville </strong> 
          <img src="./public/images/walter.jpg" alt="Walter" class="perso">
          Née le 07 Décembre 2000 à Paris.
          Diplômée d'un diplôme Supérieur d'Arts Appliqué des Beaux Arts.
          Gère notre identité artistique et les itinéraires des voyage
          Aime Le pâté et le saucisson.
        </p>
      </article>

      <article class="seul">
        <h2>Directeur Marketing et Gestion Service</h2>
        <p class="jtexte"> 
          <strong>Khalil meziane </strong>
          <img src="./public/images/khalil.png" alt="Khalil" class="perso">
          Née le 24 Décembre 2000 à Montpellier 
          Diplômée d'un DUT Technique de Commercialisation  ( Montpellier - Sète )
          Gère notre visibilité publicitaire et le gestion financière des voyages.
          Aime Dormir et squatter l'appartement des autres.
        </p>
      </article>

      <article class="seul">
        <h2>Directeur Comptabilité</h2>
        <p class="jtexte"> 
          <strong>Matthieu Giaccaglia </strong>
          <img src="./public/images/matthieu.png" alt="Matthieu" class="perso">
          Née le 26 Décembre 2000 à Montpellier 
          Diplômée d'un DUT Telecom  ( Montpellier - Sète )
          Il s'est redirigé vers la comptabilité, qui s'est avéré etre une passion
          pour lui, grace à lui aucun budget n'est déféctueux. 
          Merci à Matthieu d'etre un employé sur lequel on peut compté !
        </p>
      </article>

      <article class="seul">
        <h2>Directeur Publicitaire</h2>
        <p class="jtexte"> 
          <strong>Matthieu Giaccaglia </strong>
          <img src="./public/images/julien.jpg" alt="Julien" class="perso">
          Née le 26 Décembre 2000 à Montpellier 
          Diplômée d'un DUT Electronique
          Il a refait tout le cablage du terrain
          Grace à lui le batiment est plus connecté que jamais
        </p>
      </article>
</main>