
        <aside>
          <div class="menu_s">
            <a href=""><div class="smenu_s" onclick="location.href='./services_fils/pulls.html';"><h1>Pulls</a>
            </div>
            <a href=""><div class="smenu_s" onclick="location.href='./services_fils/shirts.html';"><h1>T-shirts</a>
            </div>
            <a href=""><div class="smenu_s" onclick="location.href='./services_fils/chaussures.html';"><h1>Chaussures</a>
            </div>
            <a href=""><div class="smenu_s" onclick="location.href='';"><h1>Pins</a></h1>
            </div><!--animation pour hover, agrandit la taille de la boite et rapetissit les autres-->
          </div>
        </aside>




        <!--<section>
            <p>
            <b>Top ventes : </b></p>
            <main class="prod">
              <article class="prod1">
                <h3>Pull noir</h3>
                  <p class="jtexte">
                    <a href="./../IMAGES/Services/pull1.png" target="blank"><img src="./../IMAGES/Services/pull1.png" alt="pull1" class="perso">
                    <img src="./../IMAGES/Services/top_seller.png" alt="topseller" class="topseller"  height="140"></a> 
                  </p>
              </article>
              <article class="prod1">
                <h3>Pull noir</h3>
                  <p class="jtexte">
                  <a href="./../IMAGES/Services/pull1.png" target="blank"><img src="./../IMAGES/Services/pull1.png" alt="pull1" class="perso"></a> 
                    <strong>20$</strong><br/>
                    Provenance: Bengladesh
                  </p>
              </article>
              <article class="prod1">
                <h3>Pulls</h3>
                  <p class="jtexte">
                  <a href="./../IMAGES/Services/pull1.png" target="blank"><img src="./../IMAGES/Services/pull1.png" alt="pull1" class="perso"></a> 
                    <strong>20$</strong><br/>
                    Provenance: Bengladesh
                  </p>
              </article>
            </main>
        </section>-->

