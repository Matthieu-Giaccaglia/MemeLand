<?php
    echo "<aside><p>Le produit a bien été supprimée</p></aside>";
    require File::build_path(array('view','admin','listAllProduct.php'));
?>
