<section>
    <h3>Panier :</h3>
    <main id="main_panier">

        <?php

            $prixTot = 0;
            if(sizeof($tab_panier)==0){
                echo "<p>Votre panier est vide</p>";
            } else {
                echo "<table class='panier'>";
                foreach ($tab_panier as $key => $value) {
                    $p = ModelProduit::select($key);
            
                    $id_produitURL = rawurldecode($p->get("id_produit"));
                    $image = $p->get("image");
                    $nomHTML = htmlspecialchars($p->get("nom"));
                    $categorieHTML = htmlspecialchars($p->get("categorie_id"));
                    $prix = $p->get("prix")*$value;
                    
                    $prixTot = $prixTot + $prix;
            
                    echo "
                                <tr>
                                    <td>
                                        <a href='?controller=produit&action=read&id_produit=$id_produitURL'>
                                            <img src='./public/images/produit/$image' alt='produit_image' height='50px'>
                                        </a>
                                    </td>
                                    <td>$nomHTML</td>
                                    <td>$categorieHTML</td>
                                    <td>$prix <strong>€</strong></td>
                                    <td>
                                        <form method='get' action=''>
                                            <input type='hidden' name='controller' value='$controller'>
                                            <input type='hidden' name='action' value='enleverPanier'>
                                            <input type='hidden' name='id_produit' value='$key'>
                                            <input class='b_input' type='submit' value='-'>
                                        </form>
                                    </td>
                                    <td>$value</td> 
                                    <td>
                                        <form method='get' action=''>
                                            <input type='hidden' name='controller' value='$controller'>
                                            <input type='hidden' name='action' value='ajoutPanier'>
                                            <input type='hidden' name='id_produit' value='$key'>
                                            <input class='b_input' type='submit' value='+'>
                                        </form>
                                    </td>
                                </tr>";
   
                }
                echo "
                    </table>
                    <div class='button'>
                        <form action='' method='get'>
                            <input type='hidden' name='controller' value='utilisateur'>
                            <p> Prix total : $prixTot</p> 
                            <button class='b_input' type='submit' name='action' value='payer'>Payer</button>
                        </form>
                    </div>";
            }
        ?>
    </main>
</section>