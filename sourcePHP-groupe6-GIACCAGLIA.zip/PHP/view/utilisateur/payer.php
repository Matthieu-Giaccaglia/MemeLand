
<?php
    echo "<section><p>Vous avez payé</p></section>";
    $_SESSION['panier'] = [];
?>