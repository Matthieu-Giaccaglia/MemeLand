<?php
    echo "<section><p>Votre panier est vide</p></section>";
?>