<?php
echo "<section><p>L'utilisateur a bien été créée</p></section>";
require File::build_path(array('view','produit','list.php'));
?>
